var express = require('express');
var router = express.Router();

const menuController = require('../controllers/menu');

router.get('/', menuController.getMenus);

router.get('/edit', menuController.getEditMenu);

router.post('/add', menuController.postAddMenu);

router.post('/update', menuController.postUpdateMenu);

router.get('/delete', menuController.getDeleteMenu);

module.exports = router;