const db = require('../util/database');

module.exports = class Menu {
    constructor(id, mealsname, drink, date) {
        this.id = id;
        this.mealsname = mealsname;
        this.drink = drink;
        this.date = date;
    }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.drink);
    return db.execute(
      'INSERT INTO menu (mealsname, drink, date) VALUES (?, ?, ?)',
      [req.body.mealsname, req.body.drink, req.body.date]
    );
  }

  // READ
  static fetchAll() {
    return db.execute('SELECT * FROM menu');
  }

  static findById(id) {
    return db.execute('SELECT * FROM menu where id = ?', [id]);
  }

  // UPDATE
  static updateById(req, res) {
    const id = req.body.id;
    const mealsname = req.body.mealsname;
    const drink = req.body.drink;
    const date = req.body.date;
    //const date = new Date();
    console.log('model:updateById()', id, mealsname, drink, date)
    return db.execute(
      'UPDATE menu SET mealsname = ?, drink = ?, date = ? WHERE id = ?', [mealsname, drink, date, id]
    );
  }


  // DELETE
  static deleteById(id) {
    return db.execute(
      'DELETE FROM menu WHERE id = ?', [id]
    );
  }


  static getCount() {
    return db.execute('SELECT COUNT(*) as count FROM menu');
  }
};