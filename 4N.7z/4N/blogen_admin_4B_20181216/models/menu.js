const db = require('../util/database');

module.exports = class Menu {
    constructor(id, mealsname, price, date) {
        this.id = id;
        this.mealsname = mealsname;
        this.price = price;
        this.date = date;
    }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.price);
    return db.execute(
      'INSERT INTO menu (mealsname, price, date) VALUES (?, ?, ?)',
      [req.body.mealsname, req.body.price, req.body.date]
    );
  }

  // READ
  static fetchAll() {
    return db.execute('SELECT * FROM menu');
  }

  static findById(id) {
    return db.execute('SELECT * FROM menu where id = ?', [id]);
  }

  // UPDATE
  static updateById(req, res) {
    const id = req.body.id;
    const mealsname = req.body.mealsname;
    const price = req.body.price;
    const date = req.body.date;
    //const date = new Date();
    console.log('model:updateById()', id, mealsname, price, date)
    return db.execute(
      'UPDATE menu SET mealsname = ?, price = ?, date = ? WHERE id = ?', [mealsname, price, date, id]
    );
  }


  // DELETE
  static deleteById(id) {
    return db.execute(
      'DELETE FROM menu WHERE id = ?', [id]
    );
  }


  static getCount() {
    return db.execute('SELECT COUNT(*) as count FROM menu');
  }
};