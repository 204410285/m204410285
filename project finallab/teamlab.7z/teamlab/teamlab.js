function Change(params) {
	document.getElementById("td5").innerHTML="●";
	document.getElementById("td6").innerHTML="●";
	document.getElementById("td62").innerHTML="●";
	document.getElementById("td7").innerHTML="●";
	document.getElementById("td72").innerHTML="●";
	document.getElementById("td81").innerHTML="●";
	document.getElementById("td82").innerHTML="●";
	document.getElementById("td9").innerHTML="●";
	document.getElementById("td91").innerHTML="●";
	document.getElementById("td92").innerHTML="●";
	document.getElementById("td11").innerHTML="●";
	document.getElementById("td11a").innerHTML="●";
	document.getElementById("td12").innerHTML="●";
	document.getElementById("td12a").innerHTML="●";
	document.getElementById("td13").innerHTML="●";
	
}

function Return(){
	document.getElementById("td5").innerHTML="知識商務 E 309";
	document.getElementById("td6").innerHTML="資料庫 E 213 ";
	document.getElementById("td62").innerHTML="網頁程式設計 B 218";
	document.getElementById("td7").innerHTML="資料庫 E 213";
	document.getElementById("td72").innerHTML="網頁程式設計 B 218";
	document.getElementById("td81").innerHTML="計算機程式語言 E 213";
	document.getElementById("td82").innerHTML="知識商務 G 315";
	document.getElementById("td9").innerHTML="計算機程式語言 E 213";
	document.getElementById("td91").innerHTML="計算機程式語言 E 213";
	document.getElementById("td92").innerHTML="知識商務 G 315";
	document.getElementById("td11").innerHTML="JavaScript網頁設計 E 213";
	document.getElementById("td11a").innerHTML="資料庫 E 213";
	document.getElementById("td12").innerHTML="JavaScript網頁設計 E 213";
	document.getElementById("td12a").innerHTML="資料庫 E 213";
	document.getElementById("td13").innerHTML="JavaScript網頁設計 E 213";
}