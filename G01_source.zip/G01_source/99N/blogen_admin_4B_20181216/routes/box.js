var express = require('express');
var router = express.Router();

const postController = require('../controllers/box');

router.get('/', postController.getBoxes);

router.get('/edit', postController.getEditBox);

router.post('/add', postController.postAddBox);

router.post('/update', postController.postUpdateBox);

router.get('/delete', postController.getDeleteBox);

module.exports = router;