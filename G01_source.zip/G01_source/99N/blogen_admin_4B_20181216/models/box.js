const db = require('../util/database');

module.exports = class Box {
    constructor(id, people, size) {
        this.id = id;
        this.people = people;
        this.size = size;
        
    }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.price);
    return db.execute(
      'INSERT INTO box (people, size) VALUES (?, ?)',
      [req.body.people, req.body.size]
    );
  }

  // READ
  static fetchAll() {
    return db.execute('SELECT * FROM box');
  }

  static findById(id) {
    return db.execute('SELECT * FROM box where id = ?', [id]);
  }

  // UPDATE
  static updateById(req, res) {
    const id = req.body.id;
    const people = req.body.people;
    const size = req.body.size;
    //const date = new Date();
    console.log('model:updateById()', id, people, size)
    return db.execute(
      'UPDATE box SET people = ?, size = ?, WHERE id = ?', [people, size, id]
    );
  }


  // DELETE
  static deleteById(id) {
    return db.execute(
      'DELETE FROM box WHERE id = ?', [id]
    );
  }


  static getCount() {
    return db.execute('SELECT COUNT(*) as count FROM box');
  }
};