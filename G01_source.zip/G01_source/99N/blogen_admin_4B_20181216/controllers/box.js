const moment = require('moment');


const Box = require('../models/box');

/* READ *****************************/

exports.getBoxes = (req, res, next) => {
  Box.fetchAll()
      .then(([rows]) => {
          for (let p of rows) {
              p.date = moment(p.date).format('MMM D, YYYY');
          }
          console.log(JSON.stringify(rows, ["id", "people", "size", "date"]));
          //res.send(JSON.stringify(rows));
          res.render('boxes', {
              data: rows,
              title: 'Box List',
          });
      })
      .catch(err => console.log(err));
};

exports.getEditBox = async (req, res, next) => {

  let box;

  const findBoxById = await Box.findById(req.query.id)
      .then(([rows]) => {
          for (let p of rows) {
              p.date = moment(p.date).format('YYYY-MM-DD');
              console.log('p.date: ', p.date);
          }
          box = rows;
          //console.log('post[0].date: ', post[0].date);
         //console.log('findPostById(): ', JSON.stringify(rows));
      })
      .catch(err => console.log(err));

  console.log('box: ', JSON.stringify(box[0].date));
  
  res.render('details1', {
      data: box,
      title: 'Edit Box',
      
 });

};

exports.postAddBox = (req, res, next) => {

  Box.add(req, res)
      .then(([rows]) => {
          res.redirect('/box');
      })
      .catch(err => console.log(err));
};



exports.postUpdateBox = (req, res, next) => {

    Box.updateById(req, res)
      .then(([rows]) => {
          res.redirect('/box');
      })
      .catch(err => console.log(err));
};

exports.getDeleteBox = (req, res, next) => {
    Box.deleteById(req.query.id)
      .then(([rows]) => {
          res.redirect('/box');
      })
      .catch();
};