const moment = require('moment');

const Post = require('../models/post');
const Store = require('../models/store');
const Menu = require('../models/menu');

exports.getDashboard = async (req, res, next) => {

  let posts;
  let postCounts;
  let stores;
  let storeCount;
  let menuCount;

  try {
    const getPosts = await Post.fetchAll()
      .then(([rows]) => {
        for (let p of rows) {
          p.date = moment(p.date).format('MMM D, YYYY');
        }
        posts = rows;
      })
    const getPostCount = await Post.getCount()
      .then(([rows]) => {
        postCount = rows[0].count;
      })

    const getstores = await Store.fetchAll()
      .then(([rows]) => {
        for (let p of rows) {
          p.date = moment(p.date).format('MMM D, YYYY');
        }
        stores = rows;
      })

    const getStoreCount = await Store.getCount()
      .then(([rows]) => {
        storeCount = rows[0].count;
      })

    const getMenuCount = await Menu.getCount()
      .then(([rows]) => {
        menuCount = rows[0].count;
        console.log('menu count 1: ', menuCount);
      })

    let data = {
      posts: posts,
      stores: stores,
      postCount: postCount,
      storeCount: storeCount,
      menuCount: menuCount
    }

    console.log(JSON.stringify(data));
    //res.send(JSON.stringify(data));

    res.render('dashboard', {
      title: 'Dashboard',
      color: 'btn-primary',
      icon: 'fa-cog',
      data: posts,
      stores: stores,
      storeCount: storeCount,
      postCount: postCount,
      menuCount: menuCount
    });

  } catch (err) {
    console.log(err);
  };

};