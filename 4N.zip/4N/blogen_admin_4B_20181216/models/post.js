const db = require('../util/database');

module.exports = class Post {
  constructor(id, name, phone, date) {
    this.id = id;
    this.name = name;
    this.phone = phone;
    this.date = date;

  }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.price);
    return db.execute(
      'INSERT INTO post (name, phone, date) VALUES (?, ?, ?)',
      [req.body.name, req.body.phone, req.body.date]
    );
  }

  // READ
  static fetchAll() {
    return db.execute('SELECT * FROM post');
  }

  static findById(id) {
    return db.execute('SELECT * FROM post where id = ?', [id]);
  }

  // UPDATE
  static updateById(req, res) {
    const id = req.body.id;
    const name = req.body.name;
    const phone = req.body.phone;
    const date = req.body.date;
    //const date = new Date();
    console.log('model:updateById()', id, name, phone, date)
    return db.execute(
      'UPDATE post SET name = ?, phone = ?, date = ? WHERE id = ?', [name, phone, date, id]
    );
  }


  // DELETE
  static deleteById(id) {
    return db.execute(
      'DELETE FROM post WHERE id = ?', [id]
    );
  }


  static getCount() {
    return db.execute('SELECT COUNT(*) as count FROM post');
  }
};