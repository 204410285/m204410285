const db = require('../util/database');

module.exports = class Post {
  constructor(id, name, phone, date, storename) {
    this.id = id;
    this.name = name;
    this.phone = phone;
    this.date = date;
    this.storename = storename;
  }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.price);
    return db.execute(
      'INSERT INTO post (name, phone, date, storename) VALUES (?, ?, ?, ?)',
      [req.body.name, req.body.phone, req.body.date, req.body.editor1]
    );
  }

  // READ
  static fetchAll() {
    return db.execute('SELECT * FROM post');
  }

  static findById(id) {
    return db.execute('SELECT * FROM post where id = ?', [id]);
  }

  // UPDATE
  static updateById(req, res) {
    const id = req.body.id;
    const name = req.body.name;
    const phone = req.body.phone;
    const date = req.body.date;
    const storename = req.body.editor1;
    //const date = new Date();
    console.log('model:updateById()', id, name, phone, date,storename)
    return db.execute(
      'UPDATE post SET name = ?, phone = ?, date = ?, storename = ? WHERE id = ?', [name, phone, date, storename, id]
    );
  }


  // DELETE
  static deleteById(id) {
    return db.execute(
      'DELETE FROM post WHERE id = ?', [id]
    );
  }


  static getCount() {
    return db.execute('SELECT COUNT(*) as count FROM post');
  }
};