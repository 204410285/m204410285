const db = require('../util/database');

module.exports = class Box {
    constructor(id, people, size, date) {
        this.id = id;
        this.people = people;
        this.size = size;
        this.date = date;
    }

    // READ
    static fetchAll() {
        return db.execute('SELECT * FROM box');
    }

    static getCount() {
        return db.execute('SELECT COUNT(*) as count FROM box');
    }
}