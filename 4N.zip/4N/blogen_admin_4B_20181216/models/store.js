const db = require('../util/database');

module.exports = class Store {
    constructor(id, storename, storephone, address, date) {
        this.id = id;
        this.storename = storename;
        this.storephone = storephone;
        this.address = address;
        this.date = date;
    }

    // READ
    static fetchAll() {
        return db.execute('SELECT * FROM store');
    }

    static getCount() {
        return db.execute('SELECT COUNT(*) as count FROM store');
    }
}