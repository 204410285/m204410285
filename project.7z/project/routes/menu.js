var express = require('express');
var router = express.Router();

const postController = require('../controllers/menu');

router.get('/', postController.getMenus);

router.get('/edit', postController.getEditMenu);

router.post('/add', postController.postAddMenu);

router.post('/update', postController.postUpdateMenu);

router.get('/delete', postController.getDeleteMenu);

module.exports = router;