var express = require('express');
var router = express.Router();

const indexController = require('../../controllers/client/index');

router.get('/', indexController.getIndex);


module.exports = router;
