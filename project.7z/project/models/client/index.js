const db = require('../../util/database');

module.exports = class Index {
    constructor(id, name, phone, date, menuid, boxid,size) {
        this.id = id;
        this.name = name;
        this.phone = phone;
        this.date = date;
        this.menuid = menuid;
        this.boxid = boxid;
        this.size = size;
      }
    // READ
    static fetchAll() {
        return db.execute('SELECT p.id,p.name,p.phone,p.date,p.menuid,p.boxid,b.size FROM post p,box b where p.boxid=b.id ');
    }

    static findById(id) {
        return db.execute('SELECT * FROM post where where id = ?', [id]);
    }
}