const moment = require('moment');

const Menu = require('../models/menu');

/* READ *****************************/

exports.getMenus = (req, res, next) => {
  Menu.fetchAll()
        .then(([rows]) => {
            for (let p of rows) {
                p.date = moment(p.date).format('MMM D, YYYY');
            }
            console.log(JSON.stringify(rows, ["id", "mealsname", "drink"]));
            //res.send(JSON.stringify(rows));
            res.render('menus', {
                data: rows,
                title: 'Menu List',
            });
        })
        .catch(err => console.log(err));
};

exports.getEditMenu = async (req, res, next) => {

    let menus;

    const getMenus = await Menu.fetchAll()
        .then(([rows]) => {
          menus = rows;
            //console.log('findboxes(): ', JSON.stringify(rows));
        })

    const findMenuById = await Menu.findById(req.query.id)
        .then(([rows]) => {
            for (let p of rows) {
                p.date = moment(p.date).format('YYYY-MM-DD');
                console.log('p.date: ', p.date);
            }
            menu = rows;
            //console.log('post[0].date: ', post[0].date);
           //console.log('findPostById(): ', JSON.stringify(rows));
        })
        .catch(err => console.log(err));

    console.log('menu: ', JSON.stringify(menu[0].date));
    
    res.render('details1', {
        data: menu,
        title: 'Edit Menu',
        menus: menus
   });

};

exports.postAddMenu = (req, res, next) => {

  Menu.add(req, res)
        .then(([rows]) => {
            res.redirect('/');
        })
        .catch(err => console.log(err));
};



exports.postUpdateMenu = (req, res, next) => {

  Menu.updateById(req, res)
        .then(([rows]) => {
            res.redirect('/');
        })
        .catch(err => console.log(err));
};

exports.getDeleteMenu = (req, res, next) => {
  Menu.deleteById(req.query.id)
        .then(([rows]) => {
            res.redirect('/menu');
        })
        .catch();
};