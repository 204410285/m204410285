const moment = require('moment');

const Index = require('../../models/client/index');

/* READ *****************************/

exports.getIndex = (req, res, next) => {
    Index.fetchAll()
        .then(([rows]) => {
            for (let p of rows) {
                p.date = moment(p.date).format('MMM D, YYYY');
            }
            console.log(JSON.stringify(rows, ["id", "title", "date"]));
            //res.send(JSON.stringify(rows));
            res.render('./client/index', {
                data: rows,
                title: 'Index List',
            });
        })
        .catch(err => console.log(err));
};

exports.postUpdateIndex = (req, res, next) => {

    Index.updateById(req, res)
        .then(([rows]) => {
            res.redirect('/');
        })
        .catch(err => console.log(err));
};
