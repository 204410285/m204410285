var express = require('express');
var router = express.Router();

const boxController = require('../controllers/box');

router.get('/', boxController.getBoxes);

router.get('/edit', boxController.getEditBox);

router.post('/add', boxController.postAddBox);

router.post('/update', boxController.postUpdateBox);

router.get('/delete', boxController.getDeleteBox);

module.exports = router;