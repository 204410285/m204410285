const db = require('../util/database');

module.exports = class  Menu {
  constructor(id, mealsname, price){
    this.id = id;
    this.mealsname = mealsname;
    this.price = price;
  }

  // READ
  static fetchAll(){
    return db.execute('SELECT * FROM menu');
  }

  static getCount(){
    return db.execute('SELECT COUNT(*) as count FROM menu');
  }
}