const db = require('../util/database');

module.exports = class Post {
  constructor(id, name, phone, date, menuid, boxid) {
    this.id = id;
    this.name = name;
    this.phone = phone;
    this.date = date;
    this.menuid = menuid;
    this.boxid = boxid;

  }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.price);
    return db.execute(
      'INSERT INTO post (name, phone, date, menuid, boxid) VALUES (?, ?, ?, ?, ?)',
      [req.body.name, req.body.phone, req.body.date, req.body.menuid, req.body.boxid]
    );
  }

  // READ
  static fetchAll() {
    return db.execute('SELECT * FROM post');
  }

  static findById(id) {
    return db.execute('SELECT * FROM post where id = ?', [id]);
  }

  // UPDATE
  static updateById(req, res) {
    const id = req.body.id;
    const name = req.body.name;
    const phone = req.body.phone;
    const date = req.body.date;
    const menuid = req.body.menuid;
    const boxid = req.body.boxid;
    //const date = new Date();
    console.log('model:updateById()', id, name, phone, date, menuid, boxid)
    return db.execute(
      'UPDATE post SET name = ?, phone = ?, date = ?, menuid = ?, boxid = ? WHERE id = ?', [name, phone, date, menuid, boxid, id]
    );
  }


  // DELETE
  static deleteById(id) {
    return db.execute(
      'DELETE FROM post WHERE id = ?', [id]
    );
  }


  static getCount() {
    return db.execute('SELECT COUNT(*) as count FROM post');
  }
};