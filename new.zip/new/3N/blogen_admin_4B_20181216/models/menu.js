const db = require('../util/database');

module.exports = class Menu {
    constructor(id, mealsname, drink) {
        this.id = id;
        this.mealsname = mealsname;
        this.drink = drink;
       
    }

  // CREATE 
  static add(req, res) {
    //console.log('add():', req.body.name, req.body.drink);
    return db.execute(
      'INSERT INTO menu (mealsname, drink) VALUES (?, ?)',
      [req.body.mealsname, req.body.drink]
    );
  }

  // READ
  static fetchAll() {
    return db.execute('SELECT * FROM menu');
  }

  static findById(id) {
    return db.execute('SELECT * FROM menu where id = ?', [id]);
  }

  // UPDATE
  static updateById(req, res) {
    const id = req.body.id;
    const mealsname = req.body.mealsname;
    const drink = req.body.drink;
    
    //const date = new Date();
    console.log('model:updateById()', id, mealsname, drink)
    return db.execute(
      'UPDATE menu SET mealsname = ?, drink = ?, WHERE id = ?', [mealsname, drink, id]
    );
  }


  // DELETE
  static deleteById(id) {
    return db.execute(
      'DELETE FROM menu WHERE id = ?', [id]
    );
  }


  static getCount() {
    return db.execute('SELECT COUNT(*) as count FROM menu');
  }
};